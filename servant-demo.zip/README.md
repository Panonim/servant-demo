> [!WARNING]
>
> This is a demo build!
> 
> The full release can be found here: https://github.com/Panonim/servant


# ServAnt
ServAnt is a lightweight, read‑only Docker dashboard designed for developers and homelabs.

Run it anywhere via Docker. ServAnt aims to be a clean, zero‑dependency way to glance at container health, ports, and resources without extra agents or complex setup.

